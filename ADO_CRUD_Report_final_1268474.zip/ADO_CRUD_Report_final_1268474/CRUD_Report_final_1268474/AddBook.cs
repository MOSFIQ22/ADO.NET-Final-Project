﻿using CRUD_Report_final_1268474.ConHalpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD_Report_final_1268474
{
    public partial class AddBook : Form
    {
        public AddBook()
        {
            InitializeComponent();
        }
        public Form1 OpenerForm { get; set; }
        public object ConnectionHelper { get; private set; }

        private void AddBook_Load(object sender, EventArgs e)
        {
            this.textBox1.Text = GetNewBookId().ToString();
            using (SqlConnection con = new SqlConnection(ConnectionHalper.ConString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("SELECT AuthorId, AuthorName FROM Authors", con))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    this.comboBox1.DataSource = dt.DefaultView;
                }
            }
        }

        private object GetNewBookId()
        {
            using (SqlConnection con = new SqlConnection(ConnectionHalper.ConString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(BookId), 0) FROM Books", con))
                {
                    con.Open();
                    int id = (int)cmd.ExecuteScalar();
                    con.Close();
                    return id + 1;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(ConnectionHalper.ConString))
            {
                con.Open();
                using (SqlTransaction tran = con.BeginTransaction())
                {

                    using (SqlCommand cmd = new SqlCommand(@"INSERT INTO Books 
                                            (BookId, CoverPrice, Title, PublishDate, Available, AuthorId) VALUES
                                            (@i, @cv, @t, @pb, @av,@ad)", con, tran))
                    {
                        cmd.Parameters.AddWithValue("@i", int.Parse(textBox1.Text));
                        cmd.Parameters.AddWithValue("@cv", decimal.Parse(textBox2.Text));
                        cmd.Parameters.AddWithValue("@t", textBox3.Text);
                        cmd.Parameters.AddWithValue("@pb", dateTimePicker2.Value);
                        cmd.Parameters.AddWithValue("@av", checkBox1.Checked);
                        cmd.Parameters.AddWithValue("@ad", (int)comboBox1.SelectedValue);

                        try
                        {
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                MessageBox.Show("Data Added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                tran.Commit();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error: {ex.Message}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            tran.Rollback();
                        }
                        finally
                        {
                            if (con.State == ConnectionState.Open)
                            {
                                con.Close();
                            }
                        }

                    }
                }

            }
        }
    }
}
