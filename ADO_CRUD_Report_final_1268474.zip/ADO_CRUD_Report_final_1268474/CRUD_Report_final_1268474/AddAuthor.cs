﻿using CRUD_Report_final_1268474.ConHalpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD_Report_final_1268474
{
    public partial class AddAuthor : Form
    {
        string filePath = "";
        List<Author> Authors = new List<Author>();
        public AddAuthor()
        {
            InitializeComponent();
        }
        public ICrossDataSync FormToReload { get; set; }
        private void button1_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(ConnectionHalper.ConString))
            {
                con.Open();
                using (SqlTransaction tran = con.BeginTransaction())
                {

                    using (SqlCommand cmd = new SqlCommand(@"INSERT INTO Authors  
                                           (AuthorId, AuthorName, Phone, Email, authorAddress, picture, BirthDate) VALUES
                                            (@i, @n, @p, @e, @a, @pi, @bd)", con, tran))
                    {
                        cmd.Parameters.AddWithValue("@i", int.Parse(textBox1.Text));
                        cmd.Parameters.AddWithValue("@n", textBox2.Text);
                        cmd.Parameters.AddWithValue("@p", textBox3.Text);
                        cmd.Parameters.AddWithValue("@e", textBox4.Text);
                        cmd.Parameters.AddWithValue("@a", textBox5.Text);
                        cmd.Parameters.AddWithValue("@bd", dateTimePicker2.Value);
                        string ext = Path.GetExtension(this.filePath);
                        string fileName = $"{Guid.NewGuid()}{ext}";
                        string savePath = Path.Combine(Path.GetFullPath(@"..\..\Pictures"), fileName);
                        File.Copy(filePath, savePath, true);
                        cmd.Parameters.AddWithValue("@pi", fileName);
                        

                        try
                        {
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                MessageBox.Show("Data Added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                Authors.Add(new Author
                                {
                                    AuthorId = int.Parse(textBox1.Text),
                                    AuthorName = textBox2.Text,
                                    Phone = textBox3.Text,
                                    Email = textBox4.Text,
                                    authorAddress = textBox5.Text,
                                    picture = fileName,
                                    BirthDate = dateTimePicker2.Value,
                                }); ;
                                tran.Commit();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error: {ex.Message}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            tran.Rollback();
                        }
                        finally
                        {
                            if (con.State == ConnectionState.Open)
                            {
                                con.Close();
                            }
                        }

                    }
                }

            }
        }
        private void AddAuthor_Load(object sender, EventArgs e)
        {
            this.textBox1.Text = this.GetNewBookId().ToString();
        }

        private int GetNewBookId()
        {
            using (SqlConnection con = new SqlConnection(ConnectionHalper.ConString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(AuthorId), 0) FROM Authors", con))
                {
                    con.Open();
                    int id = (int)cmd.ExecuteScalar();
                    con.Close();
                    return id + 1;
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.filePath = this.openFileDialog1.FileName;
                this.label7.Text = Path.GetFileName(this.filePath);
                this.pictureBox1.Image = Image.FromFile(this.filePath);
            }
        }
        private void AddAuthor_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.FormToReload.ReloadData(this.Authors);
        }
    }
}
