﻿Create table Authors
(
	AuthorId INT PRIMARY KEY,
	AuthorName NVARCHAR(40) NOT NULL,
	Phone NVARCHAR(20) NOT NULL,
	Email NVARCHAR(50) NOT NULL,
	authorAddress NVARCHAR(30)
)
GO
Create table Books
(
	BookId INT PRIMARY KEY,
	Title NVARCHAR(50) NOT NULL,
	AuthorId INT NOT NULL REFERENCES Authors(AuthorId),
	CoverPrice MONEY NOT NULL,
	PublishDate DATE NOT NULL,
	Available bit not null
)