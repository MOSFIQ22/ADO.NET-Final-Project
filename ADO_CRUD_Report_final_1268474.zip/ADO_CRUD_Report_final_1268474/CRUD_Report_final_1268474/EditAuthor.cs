﻿using CRUD_Report_final_1268474.ConHalpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD_Report_final_1268474
{
    public partial class EditAuthor : Form
    {
        string filePath, oldFile, fileName;
        string action = "Edit";
        Author author;
        public EditAuthor()
        {
            InitializeComponent();
        }
        public int AuthorToEditDelete { get; set; }
        public ICrossDataSync FormToReload { get; set; }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.filePath = this.openFileDialog1.FileName;
                this.label7.Text = Path.GetFileName(this.filePath);
                this.pictureBox1.Image = Image.FromFile(this.filePath);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.action = "Delete";
            using (SqlConnection con = new SqlConnection(ConnectionHalper.ConString))
            {
                con.Open();
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    using (SqlCommand cmd = new SqlCommand(@"DELETE  Authors 
                                            WHERE AuthorId=@i", con, tran))
                    {
                        cmd.Parameters.AddWithValue("@i", int.Parse(textBox1.Text));
                        try
                        {
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                MessageBox.Show("Data Deleted", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                tran.Commit();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error: {ex.Message}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            tran.Rollback();
                        }
                        finally
                        {
                            if (con.State == ConnectionState.Open)
                            {
                                con.Close();
                            }
                        }

                    }
                }

            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            ShowData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.action = "Edit";
            using (SqlConnection con = new SqlConnection(ConnectionHalper.ConString))
            {
                con.Open();
                using (SqlTransaction tran = con.BeginTransaction())
                {
                    using (SqlCommand cmd = new SqlCommand(@"UPDATE  Authors  
                                            SET  AuthorName=@n, Phone=@p, Email= @e, authorAddress=@a, picture=@pi, BirthDate=@bd 
                                            WHERE AuthorId=@i", con, tran))
                    {
                        cmd.Parameters.AddWithValue("@i", int.Parse(textBox1.Text));
                        cmd.Parameters.AddWithValue("@n", textBox2.Text);
                        cmd.Parameters.AddWithValue("@p", textBox3.Text);
                        cmd.Parameters.AddWithValue("@e", textBox4.Text);
                        cmd.Parameters.AddWithValue("@a", textBox5.Text);
                        cmd.Parameters.AddWithValue("@bd", dateTimePicker2.Value);
                        if (!string.IsNullOrEmpty(this.filePath))
                        {
                            string ext = Path.GetExtension(this.filePath);
                            fileName = $"{Guid.NewGuid()}{ext}";
                            string savePath = Path.Combine(Path.GetFullPath(@"..\..\Pictures"), fileName);
                            File.Copy(filePath, savePath, true);
                            cmd.Parameters.AddWithValue("@pi", fileName);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@pi", oldFile);
                        }
                        try
                        {
                            if (cmd.ExecuteNonQuery() > 0)
                            {
                                MessageBox.Show("Data Updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                author = new Author
                                {
                                    AuthorId = int.Parse(textBox1.Text),
                                    AuthorName = textBox2.Text,
                                    Phone = textBox3.Text,
                                    Email = textBox4.Text,
                                    authorAddress = textBox5.Text,
                                    picture = filePath == "" ? oldFile : fileName,
                                    BirthDate=dateTimePicker2.Value
                                };
                                tran.Commit();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error: {ex.Message}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            tran.Rollback();
                        }
                        finally
                        {
                            if (con.State == ConnectionState.Open)
                            {
                                con.Close();
                            }
                        }

                    }
                }
            }
        }
        private void EditAuthor_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (this.action == "edit")
                this.FormToReload.UpdateAuthor(author);
            else
                this.FormToReload.RemoveAuthor(Int32.Parse(this.textBox1.Text));
        }
        private void EditAuthor_Load(object sender, EventArgs e)
        {
            ShowData();
        }
        private void ShowData()
        {
            using (SqlConnection con = new SqlConnection(ConnectionHalper.ConString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Authors WHERE AuthorId =@i", con))
                {
                    cmd.Parameters.AddWithValue("@i", this.AuthorToEditDelete);
                    con.Open();
                    var dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        textBox1.Text = dr.GetInt32(0).ToString();
                        textBox2.Text = dr.GetString(1);
                        textBox3.Text = dr.GetString(2);
                        textBox4.Text = dr.GetString(3);
                        textBox5.Text = dr.GetString(4);
                        oldFile = dr.GetString(5).ToString();
                        pictureBox1.Image = Image.FromFile(Path.Combine(@"..\..\Pictures", dr.GetString(5).ToString()));
                        dateTimePicker2.Value = dr.GetDateTime(6);
                    }
                    con.Close();
                }
            }
        }
    }
}
