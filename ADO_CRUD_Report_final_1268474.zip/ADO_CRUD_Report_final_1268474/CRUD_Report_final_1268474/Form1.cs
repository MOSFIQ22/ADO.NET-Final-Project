﻿using CRUD_Report_final_1268474.ConHalpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD_Report_final_1268474
{
    public partial class Form1 : Form,ICrossDataSync
    {
        DataSet ds;
        BindingSource asAuthors = new BindingSource();
        BindingSource bsBooks = new BindingSource();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            this.dataGridView1.AutoGenerateColumns = false;
            LoadData();
            BindData();
            showNavigation();
        }

        private void BindData()
        {
            asAuthors.DataSource = ds;
            asAuthors.DataMember = "Authors";
            bsBooks.DataSource = asAuthors;
            bsBooks.DataMember = "FK_AUTHOR_BOOK";
            this.dataGridView1.DataSource = bsBooks;
            lblAuthorId.DataBindings.Add(new Binding("Text", asAuthors, "AuthorId"));
            lblAuthorName.DataBindings.Add(new Binding("Text", asAuthors, "AuthorName"));
            lblPhone.DataBindings.Add(new Binding("Text", asAuthors, "Phone"));
            lblEmail.DataBindings.Add(new Binding("Text", asAuthors, "Email"));
            lblAddress.DataBindings.Add(new Binding("Text", asAuthors, "authorAddress"));
            pictureBox1.DataBindings.Add(new Binding("Image", asAuthors, "image", true));
        }

        private void LoadData()
        {
            ds = new DataSet();
            using (SqlConnection con = new SqlConnection(ConnectionHalper.ConString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Authors", con))
                {
                    da.Fill(ds, "Authors");
                    ds.Tables["Authors"].Columns.Add(new DataColumn("image", typeof(System.Byte[])));
                    for (var i = 0; i < ds.Tables["Authors"].Rows.Count; i++)
                    {
                        ds.Tables["Authors"].Rows[i]["image"] = File.ReadAllBytes(Path.Combine(Path.GetFullPath(@"..\..\Pictures"), ds.Tables["Authors"].Rows[i]["picture"].ToString()));
                    }
                    da.SelectCommand.CommandText = "SELECT * FROM Books";
                    da.Fill(ds, "Books");
                    DataRelation rel = new DataRelation("FK_AUTHOR_BOOK",
                        ds.Tables["Authors"].Columns["AuthorId"],
                        ds.Tables["Books"].Columns["AuthorId"]);
                    ds.Relations.Add(rel);
                    ds.AcceptChanges();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            asAuthors.MoveFirst();
            showNavigation();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            asAuthors.MoveLast();
            showNavigation();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (asAuthors.Position < asAuthors.Count - 1)
            {
                asAuthors.MoveNext();
                showNavigation();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (asAuthors.Position > 0)
            {
                asAuthors.MovePrevious();
                showNavigation();
            }
        }
        private void showNavigation()
        {
            this.lblOf.Text = (asAuthors.Position + 1).ToString();
            this.lblTotal.Text = asAuthors.Count.ToString();
        }

        private void editDeleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int id = (int)(this.asAuthors.Current as DataRowView).Row[0];
            new EditAuthor { AuthorToEditDelete = id, FormToReload = this }.ShowDialog();
        }

        public void ReloadData(List<Author>Authors)
        {
            foreach (var b in Authors)
            {
                DataRow dr = ds.Tables["Authors"].NewRow();
                dr[0] = b.AuthorId;
                dr["AuthorName"] = b.AuthorName;
                dr["Phone"] = b.Phone;
                dr["Email"] = b.Email;
                dr["authorAddress"] = b.authorAddress;
                dr["picture"] = b.picture;
                dr["image"] = File.ReadAllBytes(Path.Combine(Path.GetFullPath(@"..\..\Pictures"), b.picture));
                dr["BirthDate"] = b.BirthDate;
                ds.Tables["Authors"].Rows.Add(dr);

            }
            ds.AcceptChanges();
            bsBooks.MoveLast();
        }

        public void UpdateAuthor(Author b)
        {
            for (var i = 0; i < ds.Tables["Authors"].Rows.Count; i++)
            {
                if ((int)ds.Tables["Authors"].Rows[i]["AuthorId"] == b.AuthorId)
                {
                    ds.Tables["Authors"].Rows[i]["AuthorName"] = b.AuthorName;
                    ds.Tables["Authors"].Rows[i]["BirthDate"] = b.BirthDate;
                    ds.Tables["Authors"].Rows[i]["image"] = File.ReadAllBytes(Path.Combine(Path.GetFullPath(@"..\..\Pictures"), b.picture));
                    break;
                }
            }
            ds.AcceptChanges();
        }
        public void RemoveAuthor(int id)
        {
            for (var i = 0; i < ds.Tables["Authors"].Rows.Count; i++)
            {
                if ((int)ds.Tables["Authors"].Rows[i]["AuthorId"] == id)
                {
                    ds.Tables["Authors"].Rows.RemoveAt(i);
                    break;
                }
            }
            ds.AcceptChanges();
        }
        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AddAuthor() { FormToReload = this }.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void addToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new AddBook() { OpenerForm = this }.ShowDialog();
        }

        private void editDeteteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new EditBooks() { OpenerForm = this }.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            int id = (int)(this.asAuthors.Current as DataRowView).Row[0];
            new EditAuthor { AuthorToEditDelete = id, FormToReload = this }.ShowDialog();
        }

        private void authorsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new AuthorFormDbRpt().ShowDialog();
        }

        private void booksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FormAuthorGroupRpt().ShowDialog();
        }
    }
}
