﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD_Report_final_1268474
{
    public class Author
    {
        public int AuthorId { get; set; }
        public string AuthorName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string authorAddress { get; set; }
        public string picture { get; set; }
        public DateTime BirthDate { get; set; }
    }
}
