﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD_Report_final_1268474
{
    public interface ICrossDataSync
    {
        void ReloadData(List<Author> Authors);
        void UpdateAuthor(Author author);
        void RemoveAuthor(int id);
    }
}
